## Things to add

Function overloads in custom hooks?
function overloads in components?
Omit, Pick, interface extends with props
Picking props from external libraries
Running TypeScript on CI

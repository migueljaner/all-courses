const user = {
  name: "Matt",
};

user.age = 24;

class User {
  private username: string;
}

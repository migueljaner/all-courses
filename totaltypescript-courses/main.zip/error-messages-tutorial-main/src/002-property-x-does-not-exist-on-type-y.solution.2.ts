const user: Record<string, number | string> = {
  name: "Matt",
};

user.age = 24;

class User {
  private username: string;

  constructor() {
    this.username = "";
  }
}
